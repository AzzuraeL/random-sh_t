use serde::{Deserialize, Serialize};
use rusqlite::{Row, Result};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Event {
    pub id:          String,
    pub title:       String,
    pub description: Option<String>,
    pub start_time:  String,
    pub end_time:    String,
    pub color:       String,
    pub category:    String,
    pub all_day:     bool,
    pub created_at:  String,
    pub updated_at:  String,
}

impl Event {
    pub fn from_row(row: &Row) -> Result<Self> {
        Ok(Event {
            id:          row.get(0)?,
            title:       row.get(1)?,
            description: row.get(2)?,
            start_time:  row.get(3)?,
            end_time:    row.get(4)?,
            color:       row.get(5)?,
            category:    row.get(6)?,
            all_day:     row.get::<_, i32>(7)? != 0,
            created_at:  row.get(8)?,
            updated_at:  row.get(9)?,
        })
    }
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct CreateEventRequest {
    pub title:       String,
    pub description: Option<String>,
    pub start_time:  String,
    pub end_time:    String,
    pub color:       Option<String>,
    pub category:    Option<String>,
    pub all_day:     Option<bool>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct UpdateEventRequest {
    pub title:       Option<String>,
    pub description: Option<String>,
    pub start_time:  Option<String>,
    pub end_time:    Option<String>,
    pub color:       Option<String>,
    pub category:    Option<String>,
    pub all_day:     Option<bool>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Task {
    pub id:          String,
    pub title:       String,
    pub description: Option<String>,
    pub due_date:    Option<String>,
    pub priority:    String,
    pub completed:   bool,
    pub event_id:    Option<String>,
    pub created_at:  String,
    pub updated_at:  String,
}

impl Task {
    pub fn from_row(row: &Row) -> Result<Self> {
        Ok(Task {
            id:          row.get(0)?,
            title:       row.get(1)?,
            description: row.get(2)?,
            due_date:    row.get(3)?,
            priority:    row.get(4)?,
            completed:   row.get::<_, i32>(5)? != 0,
            event_id:    row.get(6)?,
            created_at:  row.get(7)?,
            updated_at:  row.get(8)?,
        })
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CreateTaskRequest {
    pub title:       String,
    pub description: Option<String>,
    pub due_date:    Option<String>,
    pub priority:    Option<String>,
    pub event_id:    Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct UpdateTaskRequest {
    pub title:       Option<String>,
    pub description: Option<String>,
    pub due_date:    Option<String>,
    pub priority:    Option<String>,
    pub event_id:    Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct StatsResponse {
    pub total_events:   i64,
    pub total_tasks:    i64,
    pub completed_tasks: i64,
    pub upcoming_events: i64,
    pub completion_rate: f64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ApiResponse<T: Serialize> {
    pub success: bool,
    pub data:    Option<T>,
    pub message: Option<String>,
}

impl<T: Serialize> ApiResponse<T> {
    pub fn ok(data: T) -> Self {
        ApiResponse { success: true, data: Some(data), message: None }
    }
    pub fn err(msg: impl Into<String>) -> ApiResponse<()> {
        ApiResponse { success: false, data: None, message: Some(msg.into()) }
    }
}
