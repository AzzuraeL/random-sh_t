mod db;
mod models;
mod handlers;
mod errors;

use actix_web::{web, App, HttpServer, middleware};
use actix_files::Files;
use actix_cors::Cors;
use std::sync::Mutex;
use env_logger::Env;
use log::info;

pub struct AppState {
    pub db: Mutex<db::Database>,
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    dotenv::dotenv().ok();
    env_logger::init_from_env(Env::default().default_filter_or("info"));

    let host = std::env::var("HOST").unwrap_or_else(|_| "0.0.0.0".to_string());
    let port = std::env::var("PORT").unwrap_or_else(|_| "8080".to_string());
    let bind_addr = format!("{}:{}", host, port);

    let database = db::Database::new("scheduler.db").expect("Failed to initialize database");
    let data = web::Data::new(AppState {
        db: Mutex::new(database),
    });

    info!("🚀 Scheduler server running at http://{}", bind_addr);

    HttpServer::new(move || {
        let cors = Cors::default()
            .allow_any_origin()
            .allow_any_method()
            .allow_any_header();

        App::new()
            .app_data(data.clone())
            .wrap(cors)
            .wrap(middleware::Logger::default())
            // API routes
            .service(
                web::scope("/api")
                    .route("/events", web::get().to(handlers::events::list_events))
                    .route("/events", web::post().to(handlers::events::create_event))
                    .route("/events/{id}", web::get().to(handlers::events::get_event))
                    .route("/events/{id}", web::put().to(handlers::events::update_event))
                    .route("/events/{id}", web::delete().to(handlers::events::delete_event))
                    .route("/events/range/{start}/{end}", web::get().to(handlers::events::events_by_range))
                    .route("/tasks", web::get().to(handlers::tasks::list_tasks))
                    .route("/tasks", web::post().to(handlers::tasks::create_task))
                    .route("/tasks/{id}", web::put().to(handlers::tasks::update_task))
                    .route("/tasks/{id}", web::delete().to(handlers::tasks::delete_task))
                    .route("/tasks/{id}/toggle", web::patch().to(handlers::tasks::toggle_task))
                    .route("/stats", web::get().to(handlers::stats::get_stats))
            )
            // Static files
            .service(Files::new("/", "./static").index_file("index.html"))
    })
    .bind(&bind_addr)?
    .run()
    .await
}
