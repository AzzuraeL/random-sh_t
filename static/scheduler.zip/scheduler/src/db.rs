use rusqlite::{Connection, Result, params};
use crate::models::{Event, Task};

pub struct Database {
    conn: Connection,
}

impl Database {
    pub fn new(path: &str) -> Result<Self> {
        let conn = Connection::open(path)?;
        let db = Database { conn };
        db.init_tables()?;
        Ok(db)
    }

    fn init_tables(&self) -> Result<()> {
        self.conn.execute_batch("
            PRAGMA journal_mode=WAL;
            PRAGMA foreign_keys=ON;

            CREATE TABLE IF NOT EXISTS events (
                id          TEXT PRIMARY KEY,
                title       TEXT NOT NULL,
                description TEXT,
                start_time  TEXT NOT NULL,
                end_time    TEXT NOT NULL,
                color       TEXT NOT NULL DEFAULT '#6366f1',
                category    TEXT NOT NULL DEFAULT 'general',
                all_day     INTEGER NOT NULL DEFAULT 0,
                created_at  TEXT NOT NULL,
                updated_at  TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS tasks (
                id          TEXT PRIMARY KEY,
                title       TEXT NOT NULL,
                description TEXT,
                due_date    TEXT,
                priority    TEXT NOT NULL DEFAULT 'medium',
                completed   INTEGER NOT NULL DEFAULT 0,
                event_id    TEXT REFERENCES events(id) ON DELETE SET NULL,
                created_at  TEXT NOT NULL,
                updated_at  TEXT NOT NULL
            );
        ")?;
        Ok(())
    }

    // ── Events ──────────────────────────────────────────────────────────────

    pub fn get_all_events(&self) -> Result<Vec<Event>> {
        let mut stmt = self.conn.prepare(
            "SELECT id, title, description, start_time, end_time, color, category, all_day, created_at, updated_at
             FROM events ORDER BY start_time ASC"
        )?;
        let events = stmt.query_map([], Event::from_row)?.collect::<Result<Vec<_>>>()?;
        Ok(events)
    }

    pub fn get_event(&self, id: &str) -> Result<Option<Event>> {
        let mut stmt = self.conn.prepare(
            "SELECT id, title, description, start_time, end_time, color, category, all_day, created_at, updated_at
             FROM events WHERE id = ?1"
        )?;
        let mut rows = stmt.query_map(params![id], Event::from_row)?;
        Ok(rows.next().transpose()?)
    }

    pub fn get_events_in_range(&self, start: &str, end: &str) -> Result<Vec<Event>> {
        let mut stmt = self.conn.prepare(
            "SELECT id, title, description, start_time, end_time, color, category, all_day, created_at, updated_at
             FROM events WHERE start_time >= ?1 AND start_time <= ?2 ORDER BY start_time ASC"
        )?;
        let events = stmt.query_map(params![start, end], Event::from_row)?.collect::<Result<Vec<_>>>()?;
        Ok(events)
    }

    pub fn insert_event(&self, event: &Event) -> Result<()> {
        self.conn.execute(
            "INSERT INTO events (id, title, description, start_time, end_time, color, category, all_day, created_at, updated_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)",
            params![
                event.id, event.title, event.description,
                event.start_time, event.end_time, event.color,
                event.category, event.all_day as i32,
                event.created_at, event.updated_at
            ],
        )?;
        Ok(())
    }

    pub fn update_event(&self, event: &Event) -> Result<usize> {
        let n = self.conn.execute(
            "UPDATE events SET title=?2, description=?3, start_time=?4, end_time=?5,
             color=?6, category=?7, all_day=?8, updated_at=?9 WHERE id=?1",
            params![
                event.id, event.title, event.description,
                event.start_time, event.end_time, event.color,
                event.category, event.all_day as i32, event.updated_at
            ],
        )?;
        Ok(n)
    }

    pub fn delete_event(&self, id: &str) -> Result<usize> {
        Ok(self.conn.execute("DELETE FROM events WHERE id=?1", params![id])?)
    }

    // ── Tasks ────────────────────────────────────────────────────────────────

    pub fn get_all_tasks(&self) -> Result<Vec<Task>> {
        let mut stmt = self.conn.prepare(
            "SELECT id, title, description, due_date, priority, completed, event_id, created_at, updated_at
             FROM tasks ORDER BY due_date ASC, priority DESC"
        )?;
        let tasks = stmt.query_map([], Task::from_row)?.collect::<Result<Vec<_>>>()?;
        Ok(tasks)
    }

    pub fn insert_task(&self, task: &Task) -> Result<()> {
        self.conn.execute(
            "INSERT INTO tasks (id, title, description, due_date, priority, completed, event_id, created_at, updated_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)",
            params![
                task.id, task.title, task.description, task.due_date,
                task.priority, task.completed as i32, task.event_id,
                task.created_at, task.updated_at
            ],
        )?;
        Ok(())
    }

    pub fn update_task(&self, task: &Task) -> Result<usize> {
        let n = self.conn.execute(
            "UPDATE tasks SET title=?2, description=?3, due_date=?4, priority=?5,
             completed=?6, event_id=?7, updated_at=?8 WHERE id=?1",
            params![
                task.id, task.title, task.description, task.due_date,
                task.priority, task.completed as i32, task.event_id, task.updated_at
            ],
        )?;
        Ok(n)
    }

    pub fn toggle_task(&self, id: &str, now: &str) -> Result<usize> {
        Ok(self.conn.execute(
            "UPDATE tasks SET completed = NOT completed, updated_at=?2 WHERE id=?1",
            params![id, now],
        )?)
    }

    pub fn delete_task(&self, id: &str) -> Result<usize> {
        Ok(self.conn.execute("DELETE FROM tasks WHERE id=?1", params![id])?)
    }

    pub fn get_stats(&self) -> Result<(i64, i64, i64, i64)> {
        let total_events: i64 = self.conn.query_row("SELECT COUNT(*) FROM events", [], |r| r.get(0))?;
        let total_tasks: i64  = self.conn.query_row("SELECT COUNT(*) FROM tasks",  [], |r| r.get(0))?;
        let done_tasks: i64   = self.conn.query_row("SELECT COUNT(*) FROM tasks WHERE completed=1", [], |r| r.get(0))?;
        let upcoming: i64     = self.conn.query_row(
            "SELECT COUNT(*) FROM events WHERE start_time >= datetime('now')", [], |r| r.get(0)
        )?;
        Ok((total_events, total_tasks, done_tasks, upcoming))
    }
}
