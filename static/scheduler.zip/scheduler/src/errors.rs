use actix_web::HttpResponse;
use serde_json::json;

pub fn not_found(msg: &str) -> HttpResponse {
    HttpResponse::NotFound().json(json!({ "success": false, "message": msg }))
}

pub fn internal_error(msg: &str) -> HttpResponse {
    HttpResponse::InternalServerError().json(json!({ "success": false, "message": msg }))
}

pub fn bad_request(msg: &str) -> HttpResponse {
    HttpResponse::BadRequest().json(json!({ "success": false, "message": msg }))
}
