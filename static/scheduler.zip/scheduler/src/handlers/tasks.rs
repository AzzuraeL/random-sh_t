use actix_web::{web, HttpResponse};
use chrono::Utc;
use uuid::Uuid;
use crate::{AppState, models::*, errors};

pub async fn list_tasks(state: web::Data<AppState>) -> HttpResponse {
    let db = state.db.lock().unwrap();
    match db.get_all_tasks() {
        Ok(tasks) => HttpResponse::Ok().json(ApiResponse::ok(tasks)),
        Err(e)    => errors::internal_error(&e.to_string()),
    }
}

pub async fn create_task(
    state: web::Data<AppState>,
    body:  web::Json<CreateTaskRequest>,
) -> HttpResponse {
    if body.title.trim().is_empty() {
        return errors::bad_request("Title is required");
    }
    let now = Utc::now().to_rfc3339();
    let task = Task {
        id:          Uuid::new_v4().to_string(),
        title:       body.title.clone(),
        description: body.description.clone(),
        due_date:    body.due_date.clone(),
        priority:    body.priority.clone().unwrap_or_else(|| "medium".into()),
        completed:   false,
        event_id:    body.event_id.clone(),
        created_at:  now.clone(),
        updated_at:  now,
    };
    let db = state.db.lock().unwrap();
    match db.insert_task(&task) {
        Ok(_)  => HttpResponse::Created().json(ApiResponse::ok(task)),
        Err(e) => errors::internal_error(&e.to_string()),
    }
}

pub async fn update_task(
    state: web::Data<AppState>,
    path:  web::Path<String>,
    body:  web::Json<UpdateTaskRequest>,
) -> HttpResponse {
    let id = path.into_inner();
    let db = state.db.lock().unwrap();
    let mut tasks = db.get_all_tasks().unwrap_or_default();
    let task = match tasks.iter_mut().find(|t| t.id == id) {
        Some(t) => t,
        None    => return errors::not_found("Task not found"),
    };
    if let Some(t) = &body.title       { task.title       = t.clone(); }
    if let Some(d) = &body.description { task.description = Some(d.clone()); }
    if let Some(d) = &body.due_date    { task.due_date    = Some(d.clone()); }
    if let Some(p) = &body.priority    { task.priority    = p.clone(); }
    if let Some(e) = &body.event_id    { task.event_id    = Some(e.clone()); }
    task.updated_at = Utc::now().to_rfc3339();
    match db.update_task(task) {
        Ok(_)  => HttpResponse::Ok().json(ApiResponse::ok(task.clone())),
        Err(e) => errors::internal_error(&e.to_string()),
    }
}

pub async fn toggle_task(state: web::Data<AppState>, path: web::Path<String>) -> HttpResponse {
    let id = path.into_inner();
    let now = Utc::now().to_rfc3339();
    let db = state.db.lock().unwrap();
    match db.toggle_task(&id, &now) {
        Ok(0)  => errors::not_found("Task not found"),
        Ok(_)  => HttpResponse::Ok().json(ApiResponse::ok("Toggled")),
        Err(e) => errors::internal_error(&e.to_string()),
    }
}

pub async fn delete_task(state: web::Data<AppState>, path: web::Path<String>) -> HttpResponse {
    let db = state.db.lock().unwrap();
    match db.delete_task(&path.into_inner()) {
        Ok(0)  => errors::not_found("Task not found"),
        Ok(_)  => HttpResponse::Ok().json(ApiResponse::ok("Deleted")),
        Err(e) => errors::internal_error(&e.to_string()),
    }
}
