use actix_web::{web, HttpResponse};
use chrono::Utc;
use uuid::Uuid;
use crate::{AppState, models::*, errors};

pub async fn list_events(state: web::Data<AppState>) -> HttpResponse {
    let db = state.db.lock().unwrap();
    match db.get_all_events() {
        Ok(events) => HttpResponse::Ok().json(ApiResponse::ok(events)),
        Err(e) => errors::internal_error(&e.to_string()),
    }
}

pub async fn get_event(state: web::Data<AppState>, path: web::Path<String>) -> HttpResponse {
    let db = state.db.lock().unwrap();
    match db.get_event(&path.into_inner()) {
        Ok(Some(event)) => HttpResponse::Ok().json(ApiResponse::ok(event)),
        Ok(None)        => errors::not_found("Event not found"),
        Err(e)          => errors::internal_error(&e.to_string()),
    }
}

pub async fn events_by_range(
    state: web::Data<AppState>,
    path:  web::Path<(String, String)>,
) -> HttpResponse {
    let (start, end) = path.into_inner();
    let db = state.db.lock().unwrap();
    match db.get_events_in_range(&start, &end) {
        Ok(events) => HttpResponse::Ok().json(ApiResponse::ok(events)),
        Err(e)     => errors::internal_error(&e.to_string()),
    }
}

pub async fn create_event(
    state: web::Data<AppState>,
    body:  web::Json<CreateEventRequest>,
) -> HttpResponse {
    if body.title.trim().is_empty() {
        return errors::bad_request("Title is required");
    }
    let now = Utc::now().to_rfc3339();
    let event = Event {
        id:          Uuid::new_v4().to_string(),
        title:       body.title.clone(),
        description: body.description.clone(),
        start_time:  body.start_time.clone(),
        end_time:    body.end_time.clone(),
        color:       body.color.clone().unwrap_or_else(|| "#6366f1".into()),
        category:    body.category.clone().unwrap_or_else(|| "general".into()),
        all_day:     body.all_day.unwrap_or(false),
        created_at:  now.clone(),
        updated_at:  now,
    };
    let db = state.db.lock().unwrap();
    match db.insert_event(&event) {
        Ok(_)  => HttpResponse::Created().json(ApiResponse::ok(event)),
        Err(e) => errors::internal_error(&e.to_string()),
    }
}

pub async fn update_event(
    state: web::Data<AppState>,
    path:  web::Path<String>,
    body:  web::Json<UpdateEventRequest>,
) -> HttpResponse {
    let id = path.into_inner();
    let db = state.db.lock().unwrap();
    let mut event = match db.get_event(&id) {
        Ok(Some(e)) => e,
        Ok(None)    => return errors::not_found("Event not found"),
        Err(e)      => return errors::internal_error(&e.to_string()),
    };
    if let Some(t) = &body.title       { event.title       = t.clone(); }
    if let Some(d) = &body.description { event.description = Some(d.clone()); }
    if let Some(s) = &body.start_time  { event.start_time  = s.clone(); }
    if let Some(e) = &body.end_time    { event.end_time    = e.clone(); }
    if let Some(c) = &body.color       { event.color       = c.clone(); }
    if let Some(c) = &body.category    { event.category    = c.clone(); }
    if let Some(a) = body.all_day      { event.all_day     = a; }
    event.updated_at = Utc::now().to_rfc3339();
    match db.update_event(&event) {
        Ok(_)  => HttpResponse::Ok().json(ApiResponse::ok(event)),
        Err(e) => errors::internal_error(&e.to_string()),
    }
}

pub async fn delete_event(state: web::Data<AppState>, path: web::Path<String>) -> HttpResponse {
    let db = state.db.lock().unwrap();
    match db.delete_event(&path.into_inner()) {
        Ok(0)  => errors::not_found("Event not found"),
        Ok(_)  => HttpResponse::Ok().json(ApiResponse::ok("Deleted")),
        Err(e) => errors::internal_error(&e.to_string()),
    }
}
