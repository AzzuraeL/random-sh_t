use actix_web::{web, HttpResponse};
use crate::{AppState, models::*};
use crate::errors;

pub async fn get_stats(state: web::Data<AppState>) -> HttpResponse {
    let db = state.db.lock().unwrap();
    match db.get_stats() {
        Ok((total_events, total_tasks, completed_tasks, upcoming_events)) => {
            let completion_rate = if total_tasks > 0 {
                (completed_tasks as f64 / total_tasks as f64) * 100.0
            } else {
                0.0
            };
            HttpResponse::Ok().json(ApiResponse::ok(StatsResponse {
                total_events,
                total_tasks,
                completed_tasks,
                upcoming_events,
                completion_rate,
            }))
        }
        Err(e) => errors::internal_error(&e.to_string()),
    }
}
