# 🗓 Chrono Scheduler

A full-stack scheduler web app built with **Rust** (Actix-Web) + **SQLite** + vanilla JS frontend.

## Architecture

```
scheduler/
├── src/
│   ├── main.rs          ← App entry point, routing, state
│   ├── db.rs            ← SQLite database layer (rusqlite)
│   ├── models.rs        ← Serde types (Event, Task, ApiResponse)
│   ├── errors.rs        ← Error response helpers
│   └── handlers/
│       ├── mod.rs
│       ├── events.rs    ← CRUD for events
│       ├── tasks.rs     ← CRUD + toggle for tasks
│       └── stats.rs     ← Dashboard statistics
├── static/
│   └── index.html       ← Single-file SPA (no framework)
├── Cargo.toml
├── .env
├── scheduler.service    ← Systemd unit file
├── nginx.conf           ← Reverse proxy config
└── deploy.sh            ← One-shot Kali deploy script
```

## Tech Stack

| Layer    | Tech                          |
|----------|-------------------------------|
| Runtime  | Rust (stable)                 |
| HTTP     | Actix-Web 4                   |
| Database | SQLite via rusqlite (bundled) |
| Frontend | Vanilla JS + CSS variables    |
| Fonts    | DM Serif Display + DM Sans    |
| Proxy    | Nginx                         |
| Process  | Systemd                       |

## API Endpoints

```
GET    /api/events                  → list all events
POST   /api/events                  → create event
GET    /api/events/:id              → get event
PUT    /api/events/:id              → update event
DELETE /api/events/:id              → delete event
GET    /api/events/range/:start/:end → events in date range

GET    /api/tasks                   → list all tasks
POST   /api/tasks                   → create task
PUT    /api/tasks/:id               → update task
PATCH  /api/tasks/:id/toggle        → toggle completed
DELETE /api/tasks/:id               → delete task

GET    /api/stats                   → dashboard statistics
```

---

## Local Development

### Prerequisites
- Rust stable: https://rustup.rs

```bash
# Clone / enter project
cd scheduler

# Run in dev mode (hot-ish: re-run on changes)
cargo run

# Open browser
open http://localhost:8080
```

---

## Kali Linux Deployment

### Option A — Automated (Recommended)

```bash
# Make sure you have the project on your Kali machine, then:
sudo bash deploy.sh
```

This script will:
1. Install build tools, nginx via apt
2. Install Rust if not present
3. Build release binary (`cargo build --release`)
4. Create a `scheduler` system user
5. Deploy binary + static files to `/opt/scheduler/`
6. Install & start systemd service
7. Configure nginx reverse proxy
8. Open firewall ports (if ufw is active)

### Option B — Manual Steps

```bash
# 1. Install Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source "$HOME/.cargo/env"

# 2. Install system dependencies
sudo apt install -y build-essential libssl-dev pkg-config nginx

# 3. Build
cargo build --release

# 4. Create deploy dir
sudo mkdir -p /opt/scheduler/static
sudo cp target/release/scheduler /opt/scheduler/
sudo cp -r static/* /opt/scheduler/static/
sudo cp .env /opt/scheduler/

# 5. Create system user
sudo useradd -r -s /sbin/nologin scheduler
sudo chown -R scheduler:scheduler /opt/scheduler

# 6. Install systemd service
sudo cp scheduler.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now scheduler

# 7. Configure nginx
sudo cp nginx.conf /etc/nginx/sites-available/scheduler
sudo ln -s /etc/nginx/sites-available/scheduler /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl restart nginx

# 8. Check status
sudo systemctl status scheduler
sudo journalctl -u scheduler -f
```

---

## Useful Commands

```bash
# View logs
sudo journalctl -u scheduler -f

# Restart service
sudo systemctl restart scheduler

# Stop service
sudo systemctl stop scheduler

# Rebuild & redeploy after code changes
cargo build --release
sudo cp target/release/scheduler /opt/scheduler/
sudo systemctl restart scheduler

# Check nginx
sudo nginx -t
sudo systemctl status nginx
```

## HTTPS with Let's Encrypt

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

Then uncomment the HTTPS block in `nginx.conf`.

---

## Environment Variables

| Variable  | Default   | Description          |
|-----------|-----------|----------------------|
| HOST      | 0.0.0.0   | Bind address         |
| PORT      | 8080      | Listen port          |
| RUST_LOG  | info      | Log level            |
