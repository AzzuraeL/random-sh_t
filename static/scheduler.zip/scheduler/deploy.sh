#!/usr/bin/env bash
# =============================================================
#  Chrono Scheduler – Kali Linux Deploy Script
#  Run as root: sudo bash deploy.sh
# =============================================================
set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error() { echo -e "${RED}[ERR]${NC}   $1"; exit 1; }

[[ $EUID -ne 0 ]] && error "Run as root: sudo bash deploy.sh"

APP_DIR=/opt/scheduler
BIN_NAME=scheduler
SERVICE_NAME=scheduler
NGINX_CONF=/etc/nginx/sites-available/scheduler

# ── 1. Install dependencies ──────────────────────────────────
info "Updating packages…"
apt-get update -qq

info "Installing build tools, nginx, curl…"
apt-get install -y -qq build-essential curl pkg-config libssl-dev nginx

# ── 2. Install Rust if missing ───────────────────────────────
if ! command -v cargo &>/dev/null; then
  info "Installing Rust via rustup…"
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain stable
  source "$HOME/.cargo/env"
else
  info "Rust already installed: $(rustc --version)"
fi

export PATH="$HOME/.cargo/bin:$PATH"

# ── 3. Build release binary ──────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
info "Building release binary (this takes a few minutes)…"
cd "$SCRIPT_DIR"
cargo build --release
info "Build complete: target/release/$BIN_NAME"

# ── 4. Create app user ───────────────────────────────────────
if ! id "$SERVICE_NAME" &>/dev/null; then
  info "Creating system user: $SERVICE_NAME"
  useradd -r -s /sbin/nologin -d "$APP_DIR" "$SERVICE_NAME"
fi

# ── 5. Deploy files ──────────────────────────────────────────
info "Deploying to $APP_DIR…"
mkdir -p "$APP_DIR/static"
cp "target/release/$BIN_NAME" "$APP_DIR/"
cp -r static/*                "$APP_DIR/static/"
cp .env                        "$APP_DIR/" 2>/dev/null || true
chown -R "$SERVICE_NAME:$SERVICE_NAME" "$APP_DIR"
chmod +x "$APP_DIR/$BIN_NAME"

# ── 6. Systemd service ───────────────────────────────────────
info "Installing systemd service…"
cp scheduler.service "/etc/systemd/system/${SERVICE_NAME}.service"
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"
sleep 2
if systemctl is-active --quiet "$SERVICE_NAME"; then
  info "Service is running ✓"
else
  error "Service failed to start. Check: journalctl -u $SERVICE_NAME -n 50"
fi

# ── 7. Nginx ─────────────────────────────────────────────────
info "Configuring nginx…"
cp nginx.conf "$NGINX_CONF"
ln -sf "$NGINX_CONF" /etc/nginx/sites-enabled/
# Remove default site if present
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx
info "Nginx configured ✓"

# ── 8. Firewall (ufw) ────────────────────────────────────────
if command -v ufw &>/dev/null; then
  info "Configuring firewall…"
  ufw allow 'Nginx Full' 2>/dev/null || true
  ufw allow 22/tcp 2>/dev/null || true
fi

# ── Done ─────────────────────────────────────────────────────
SERVER_IP=$(hostname -I | awk '{print $1}')
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   Chrono Scheduler deployed!             ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  URL  : http://${SERVER_IP}              ${NC}"
echo -e "${GREEN}║  Logs : journalctl -u $SERVICE_NAME -f   ║${NC}"
echo -e "${GREEN}║  Stop : systemctl stop $SERVICE_NAME     ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
