/////////////////////////////////////////////////////////////////////////
// This file is checked in as bxversion.h.in.  The configure script
// substitutes variables and creates bxversion.h.
/////////////////////////////////////////////////////////////////////////

#define VERSION       "2.8"
#define VER_DEVFLAG   0
#define REL_STRING    "Built from GitHub snapshot on March 10, 2024"
#define REL_TIMESTAMP "Sun Mar 10 08:00:00 CET 2024"
