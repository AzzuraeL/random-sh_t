#ifndef __STD_TYPE_H__
#define __STD_TYPE_H__

typedef unsigned char byte;

typedef char bool;
#define true 1
#define false 0

#define SECTOR_SIZE 512

#endif // __STD_YPE_H__
